## Конфигурация приложения (PostgreSQL)

Проект настраивается через **Spring Profiles** и **переменные окружения**. Чувствительные данные (логин/пароль к БД) **не хранятся в коде** и **не коммитятся** в репозиторий.

### Профили

- **dev** — разработка: PostgreSQL, удобные логи, можно включать автосоздание схемы/инициализацию
- **test** — тесты: H2 (in-memory), без PostgreSQL и без Docker
- *(опционально)* **prod** — прод: PostgreSQL строго через env, без автогенерации схемы

Профиль выбирается переменной окружения:

- `SPRING_PROFILES_ACTIVE=dev|test|prod`

> Если профиль не задан, Spring Boot использует профиль по умолчанию (обычно `dev`, если так настроено в `application.yml`).

---

### Переменные окружения для PostgreSQL

- `DB_URL` — JDBC URL (пример: `jdbc:postgresql://<host>:5432/<db>`)
- `DB_USERNAME` — пользователь БД
- `DB_PASSWORD` — пароль БД

Эти переменные подставляются в `application-dev.yml` / `application-prod.yml` через плейсхолдеры Spring вида `${DB_URL}`, `${DB_USERNAME}`, `${DB_PASSWORD}`.

---

## Запуск приложения

### PowerShell (построчно)

```powershell
$env:SPRING_PROFILES_ACTIVE="dev"
$env:DB_URL="jdbc:postgresql://<host>:5432/<db>"
$env:DB_USERNAME="<user>"
$env:DB_PASSWORD="<password>"

mvn spring-boot:run
```

### PowerShell (в одну строку)

```powershell
$env:SPRING_PROFILES_ACTIVE="dev"; $env:DB_URL="jdbc:postgresql://<host>:5432/<db>"; $env:DB_USERNAME="<user>"; $env:DB_PASSWORD="<password>"; mvn spring-boot:run
```

---

### CMD (построчно)

```cmd
set SPRING_PROFILES_ACTIVE=dev
set DB_URL=jdbc:postgresql://<host>:5432/<db>
set DB_USERNAME=<user>
set DB_PASSWORD=<password>

mvn spring-boot:run
```

### CMD (в одну строку)

```cmd
set SPRING_PROFILES_ACTIVE=dev&& set DB_URL=jdbc:postgresql://<host>:5432/<db>&& set DB_USERNAME=<user>&& set DB_PASSWORD=<password>&& mvn spring-boot:run
```

---

### Linux/macOS (bash/zsh) в одну строку

```bash
SPRING_PROFILES_ACTIVE=dev DB_URL="jdbc:postgresql://<host>:5432/<db>" DB_USERNAME="<user>" DB_PASSWORD="<password>" mvn spring-boot:run
```

---

## Переключение профилей

### Запуск с профилем `dev`

```bash
SPRING_PROFILES_ACTIVE=dev mvn spring-boot:run
```

### Запуск с профилем `prod` (все параметры обязаны быть переданы через env)

```bash
SPRING_PROFILES_ACTIVE=prod DB_URL="jdbc:postgresql://<host>:5432/<db>" DB_USERNAME="<user>" DB_PASSWORD="<password>" mvn spring-boot:run
```

### Запуск тестов (профиль `test`)

Интеграционные тесты настроены на профиль `test` и используют H2.

```bash
mvn test
```

> Если нужно принудительно указать профиль для тестов через Maven:
> - Windows PowerShell: `$env:SPRING_PROFILES_ACTIVE="test"; mvn test`
> - Linux/macOS: `SPRING_PROFILES_ACTIVE=test mvn test`

---

## Гигиена секретов

- **Не коммитить** реальные креды.
- Локальные значения можно хранить в `.env` (не коммитить) и добавить в `.gitignore`:
    - `.env`
    - `.env.*`
- В репозиторий можно положить шаблон `env.example` только с плейсхолдерами.



### Demo data

При старте приложения данные загружаются из CSV-файлов:

- `users.csv`
- `courses.csv`
- `enrollments.csv`

Загрузка выполняется автоматически через `CommandLineRunner`.
Повторная инициализация не происходит, если таблицы уже содержат данные.


### TODO
- добавить Flyway/Liquibase (упорядоченные колонки в таблицах)